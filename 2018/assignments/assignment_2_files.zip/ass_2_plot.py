######################################################################
# Author:      Patrick Kasper
# MatNr:       0730294
# Description: Plotting functionality for the second Task
# Comments:    Requires the seaborn package
#              install with: pip install seaborn
######################################################################

# plotting imports
import numpy as np
from matplotlib import pyplot as plt
import seaborn as sns


def plot_data(title, data_orig=None, data_smooth=None, filename=None):
    color_palette = sns.color_palette("Paired")
    fig, ax = plt.subplots(figsize=(12, 7))
    ax.set_title(title)
    
    if data_orig is not None:
        ax.plot(data_orig['timestamp'], 
                data_orig['P1'], 
                label="$PM_{10}$", 
                lw=0.5, 
                ls="--", color=color_palette[5])
        
        ax.plot(data_orig['timestamp'], 
                data_orig['P2'], 
                label="$PM_{2.5}$", 
                lw=0.5, 
                ls="--", 
                color=color_palette[7])
    
    
    ax2 = ax.twinx()
    
    if data_smooth is not None:
        fill_p1 = [x if x is not None else 0 for x in data_smooth['P1']]
        fill_p2 = [x if x is not None else 0 for x in data_smooth['P2']]

        f_1 = ax2.fill_between(data_smooth['timestamp'], 
                               np.zeros(len(data_smooth['P1'])), 
                               fill_p1, 
                               lw=1, 
                               facecolor=color_palette[0], 
                               edgecolor=color_palette[1], 
                               alpha=0.8, 
                               label="$PM_{10}$")
        f_2 = ax2.fill_between(data_smooth['timestamp'], 
                               np.zeros(len(data_smooth['P2'])), 
                               fill_p2, 
                               lw=1, 
                               facecolor=color_palette[2], 
                               edgecolor=color_palette[3], 
                               alpha=0.8, 
                               label="$PM_{2.5}$")

    ax.legend(title="Original", 
              loc=2, 
              facecolor="white")
    ax2.legend(title="Smoothed", 
               loc=1, 
               facecolor="white")
    fig.tight_layout()
    fig.autofmt_xdate()
    sns.despine(ax=ax, trim=True)
    if filename:
        fig.savefig(filename)
